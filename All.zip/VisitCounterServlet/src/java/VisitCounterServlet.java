/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.ServletContext;

@WebServlet("/visit-counter")
public class VisitCounterServlet extends HttpServlet {
    public void init() throws ServletException {
        // Initialize the visit counter
        ServletContext context = getServletContext();
        context.setAttribute("visitCounter", 0);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        ServletContext context = getServletContext();
        Integer visitCounter = (Integer) context.getAttribute("visitCounter");
        
        // Increment the visit counter
        visitCounter++;
        context.setAttribute("visitCounter", visitCounter);

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<head>");
        out.println("<title>Visit Counter</title>");
        out.println("<style>");
        out.println("body { background-color: #f2f2f2; font-family: Arial, sans-serif; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }");
        out.println(".container { background: white; padding: 20px; border-radius: 10px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }");
        out.println("</style>");
        out.println("</head>");
        out.println("<body>");
        out.println("<div class='container'>");
        out.println("<h2>Page Visit Counter</h2>");
        out.println("<p>This page has been visited " + visitCounter + " times.</p>");
        out.println("</div>");
        out.println("</body>");
        out.println("</html>");
    }
}

